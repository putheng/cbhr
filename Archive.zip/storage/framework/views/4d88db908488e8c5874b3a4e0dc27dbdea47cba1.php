<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Edit your profile</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<div class="well1 white">
    	        <form action="<?php echo e(route('publisher.profile')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

    				<?php echo e(method_field('PATCH')); ?>

					<fieldset>
    			    
        			    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    						<label class="control-label">Name :</label>
    						<input name="name" type="text" value="<?php echo e(old('name') ? old('name') : auth()->user()->name); ?>" class="form-control1">
    						<?php if($errors->has('name')): ?>
    							<span class="help-block"><?php echo e($errors->first('name')); ?></span>
    						<?php endif; ?>
    					</div>
    			    
        			    <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
    						<label class="control-label">Phone :</label>
    						<input name="phone" type="text" value="<?php echo e(old('phone') ? old('phone') : auth()->user()->password); ?>" class="form-control1">
    						<?php if($errors->has('phone')): ?>
    							<span class="help-block"><?php echo e($errors->first('phone')); ?></span>
    						<?php endif; ?>
    				    </div>
    			        <br>
    			        <input type="submit" value="Save" class="btn btn-info">
    			    </fieldset>
    		    </form>
    			    
			</div>
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publisher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>