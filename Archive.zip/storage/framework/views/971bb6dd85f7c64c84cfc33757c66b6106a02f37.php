<?php $__env->startSection('content'); ?>


<div class="row">
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-info">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-3">
						<i class="white-link fa fa-list-alt fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge"><?php echo e($listings->total()); ?></div>
						<div>Jobs</div>
					</div>
				</div>
			</div>
			<a href="<?php echo e(route('admin.listing.index')); ?>">
				<div class="panel-footer gray-gradient">
					<span class="pull-left">View Details</span>
					<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
					<div class="clearfix"></div>
				</div>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-green">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-users fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge"><?php echo e($publishers); ?></div>
						<div>Publishers</div>
					</div>
				</div>
			</div>
			<a href="#users-jobseekers">
				<div class="panel-footer gray-gradient">
					<span class="pull-left">View Details</span>
					<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
					<div class="clearfix"></div>
				</div>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-yellow">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-institution fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge"><?php echo e($companies->total()); ?></div>
						<div>Employers</div>
					</div>
				</div>
			</div>
			<a href="#users-employers">
				<div class="panel-footer gray-gradient">
					<span class="pull-left">View Details</span>
					<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
					<div class="clearfix"></div>
				</div>
			</a>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="panel panel-red">
			<div class="panel-heading">
				<div class="row">
					<div class="col-xs-3">
						<i class="fa fa-bar-chart-o fa-5x"></i>
					</div>
					<div class="col-xs-9 text-right">
						<div class="huge">0</div>
						<div>Job Applications</div>
					</div>
				</div>
			</div>
			<a href="#jobs-applications">
				<div class="panel-footer gray-gradient">
					<span class="pull-left">View Details</span>
					<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
					<div class="clearfix"></div>
				</div>
			</a>
		</div>
	</div>
</div>
<?php echo $__env->make('admin.partials.latest_employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
	<div class="col-lg-8">
		<div class="panel panel-default">
			<div class="panel-heading gray-gradient">
				<i class="fa fa-bar-chart-o"></i> 
				Job Statistics	
			</div>
			<div class="panel-body">
				<br/>
				<div class="flot-chart">
					<div class="flot-chart-content" id="flot-bar-chart"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="panel panel-default">
			<div class="panel-heading gray-gradient">
				<i class="fa fa-calendar fa-fw"></i> Latest Jobs			
			</div>
			<div class="panel-body">
				<div class="list-group">
				    <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    					<a target="_blank" href="<?php echo e(route('listing.show', $listing)); ?>" class="list-group-item">
    						<i class="fa fa-list-alt"></i>
    						    <?php echo e($listing->title); ?>

    						<span class="pull-right text-muted small">
    						    <em><?php echo e($listing->created_at->diffForHumans()); ?></em>
    						</span>
    						<div class="clearfix"></div>
    					</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<a href="#jobs-list" class="btn btn-default btn-block">View All</a>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>