<p class="h1 light" style="margin-top:0;text-align:right;">More than
	<b><a href="<?php echo e(route('listing.index')); ?>"><?php echo e($listings->count()); ?></a></b> available jobs
</p>
<ul class="nav nav-tabs" role="tablist">
	<li role="presentation" class="active">
		<a href="#by_category" aria-controls="by_category" role="tab" data-toggle="tab">
			Jobs by Category
		</a>
	</li>
	<li role="presentation" class="">
		<a href="#by_location" aria-controls="by_location" role="tab" data-toggle="tab">
			Jobs by Location
		</a>
	</li>
	<li role="presentation" class="">
		<a href="#by_salary" aria-controls="by_salary" role="tab" data-toggle="tab">
			Jobs by Salary
		</a>
	</li>
</ul>
<div class="tab-content padding-5">
	<div role="tabpanel" class="tab-pane active" id="by_category">
		<!--jobs by category-->
		<div class="row">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4 no-left-padding">
						<div class="category_link">
							<a href="<?php echo e(route('listing.search')); ?>?category=<?php echo e($category->id); ?>" class="main_category_link" title="<?php echo e($category->name); ?>">
								<?php echo e($category->name); ?>

							</a>
						</div>
						
						<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<span class="sub_category_link">
								<a title="<?php echo e($child->name); ?>" href="<?php echo e(route('listing.search')); ?>?category=<?php echo e($child->id); ?>"><?php echo e($child->name); ?></a>
							</span>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<!--end jobs by category-->
	</div>
	<div role="tabpanel" class="tab-pane" id="by_location">
		<!--jobs by location-->
		<div class="row">
			<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4 no-left-padding">
						<div class="category_link">
							<a href="<?php echo e(route('listing.search')); ?>?area=<?php echo e($area->id); ?>" class="main_category_link" title="<?php echo e($area->name); ?>">
								<?php echo e($area->name); ?>

							</a>
						</div>
						
						<?php $__currentLoopData = $area->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<span class="sub_category_link">
								<a title="<?php echo e($city->name); ?>" href="<?php echo e(route('listing.search')); ?>?area=<?php echo e($city->id); ?>"><?php echo e($city->name); ?></a>
							</span>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<!--end jobs by location-->
	</div>
	<div role="tabpanel" class="tab-pane" id="by_salary">
		<div class="row">
			<?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 no-left-padding">
					<div class="category_link">
						<a href="<?php echo e(route('listing.search')); ?>?s=<?php echo e($salary->id); ?>" class="main_category_link" title="<?php echo e($salary->name); ?>">
							<?php echo e($salary->name); ?>

						</a>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>