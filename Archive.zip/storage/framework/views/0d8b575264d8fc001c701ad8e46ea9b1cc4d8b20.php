<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading gray-gradient">
				<i class="fa fa-briefcase fa-fw"></i> 
				Latest Employers	
			</div>
			<!-- /.panel-heading -->
			<div style="padding:10px" class="btn-block">
				<div class="xpanel-body">
					<div class="table-responsive">
						<table class="table table-hover">
							<thead>
								<tr>
									<th>Date</th>
									<th>Company</th>
									<th>Contact Person</th>
									<th>Address</th>
									<th>Phone</th>
									<th>Email</th>
								</tr>
							</thead>
							<tbody>
							    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    								<tr>
    									<td><?php echo e($company->created_at->diffForHumans()); ?></td>
    									<td><?php echo e($company->name); ?></td>
    									<td><?php echo e($company->user->name); ?></td>
    									<td><?php echo e($company->address); ?></td>
    									<td><?php echo e($company->phone); ?></td>
    									<td><?php echo e($company->user->email); ?></td>
    								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
				<a href="#users-employers" class="btn btn-default btn-block">View All</a>
			</div>
		</div>
	</div>
</div>