<?php $__env->startSection('title'); ?>
    <title><?php echo e($listing->title); ?> | <?php echo e($listing->company->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-wrap">
	<div class="page-wrap">
		<a id="go_back_button" class="btn btn-default btn-xs pull-right no-decoration margin-bottom-5" href="javascript:GoBack()">Go Back</a>
		<div class="clearfix"></div>
		<div class="job-details-wrap">
			
			<h2 class="no-margin"><?php echo e($listing->title); ?></h2>
			<div class="icon-h5">
				<h5><span class="glyphicon glyphicon-equalizer"></span> <?php echo e($listing->company->name); ?></h5>
				<h5><span class="glyphicon glyphicon-map-marker"></span> 
					<?php echo e(optional($listing->area->parent)->name); ?> &raquo 
					<?php echo e($listing->area->name); ?>

				</h5>
				<h5><span class="glyphicon glyphicon-time"></span>  <?php echo e($listing->started); ?> => <?php echo e($listing->closing); ?></h5>
			</div>
			<div class="job-details-info">
				<div class="row">
					<div class="col-md-6">
						<table class="job-require table table-bordered">
							<tbody>
								<tr>
									<td>Career Level</td>
									<td><?php echo e($listing->level->name); ?></td>
								</tr>
								<tr>
									<td>Yr(s)Exp</td>
									<td><?php echo e($listing->experience->name); ?></td>
								</tr>
								<tr>
									<td>Qualification</td>
									<td><?php echo e($listing->education->name); ?></td>
								</tr>
								<tr>
									<td>Salary</td>
									<td><?php echo e($listing->salary->name); ?></td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-md-6">
						<table class="job-require table table-bordered">
							<tbody>
								<tr>
									<td>Job Type</td>
									<td><?php echo e($listing->term->name); ?></td>
								</tr>
								<tr>
									<td>Job function</td>
									<td><?php echo e($listing->category->name); ?></td>
								</tr>
								<tr>
									<td>Gender</td>
									<td><?php echo e($listing->gender->name); ?></td>
								</tr>
								<tr>
									<td>Age</td>
									<td><?php echo e($listing->age->name); ?></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-8">
					<br>
					<div class="row">
						<div class="col-md-12">
							<h4 class="border-b">Description</h4>
							<p><?php echo nl2br($listing->description); ?></p>									
						</div>
						<div class="col-md-12 margin-top-10">
							<h4 class="border-b">Requirements</h4>
							<p><?php echo nl2br($listing->requirement); ?></p>							
						</div>
						<div class="col-md-12 margin-top-10">
							<h4 class="border-b">Contact Information</h4>
							<table class="table-contact">
								<tbody>
									<tr>
										<td><b>Person</b></td>
										<td><?php echo e($listing->user->name); ?></td>
									</tr>
									<tr>
										<td><b>Phone</b></td>
										<td><?php echo e($listing->company->phone); ?></td>
									</tr>
									<tr>
										<td><b>Email</b></td>
										<td>
											<?php echo email_protected($listing->user->email); ?>

										</td>
									</tr>
									<tr>
										<td><b>Address</b></td>
										<td><?php echo e($listing->company->address); ?></td>
									</tr>
									<tr>
										<td><b>Website</b></td>
										<td>
											<a href="<?php echo e($listing->company->website); ?>" target="_blank">
												<?php echo e($listing->company->website); ?>

											</a>
										</td>
									</tr>
									<tr>
										<td>
											<b class="text-danger">Note:</b>
										</td>
										<td class="text-danger">
											កំុភ្លេចនិយាយថាអ្នកបានឃើញការផ្សព្វផ្សាយនេះនៅលើ CambodiaHR.com
											<br>
											Don't forget to mention that you found this ad on CambodiaHR.com 
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-4 text-center">
					<br>
					<a href="<?php echo e(route('company.show', $listing->company)); ?>">
						<?php if(!empty($listing->company->avatarPath())): ?>
						<img style="margin:auto;" class="logo-border img-responsive" src="<?php echo e($listing->company->avatarPath()); ?>" alt="Sales and Marketing Supervisor ($400-$800)">
						<?php else: ?>
            				<p class="text-center">
                            	<span class="feed-company"><?php echo e($listing->company->name); ?></span>
                            </p>
        				<?php endif; ?>
					</a>
					<div class="clearfix underline-link"></div>
					<a href="<?php echo e(route('company.show', $listing->company)); ?>" class="sub-text underline-link">Company Details</a>
				</div>
			</div>
			<div class="clearfix"></div>
			<br>
			<img class="l-margin-20" src="<?php echo e(asset('images/save-small-icon.png')); ?>" height="12">
			<a class="small-link gray-link" href="javascript:SaveListing(<?php echo e($listing->id); ?>)" id="save_<?php echo e($listing->id); ?>">Save this job</a>	
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>

	<div class="gray-wrap">
		<h4 class="aside-header">Related Jobs</h4>
		
		<?php $__currentLoopData = $listing->relates(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<hr class="top-bottom-margin">
		<div>			
			<h5 class="no-margin">
				<a class="jobDetail" href="<?php echo e(route('listing.show', $list)); ?>"><?php echo e($list->title); ?></a>
			</h5>
			<span class="sub-text"><?php echo e(str_limit($list->description, 150)); ?></span>
		</div>
		<div class="clearfix"></div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		<hr class="top-bottom-margin">
		<div class="text-center">
			<a class="underline-link" href="#">See All</a>
		</div>
		<br>
	</div>
	<br>
	<h3 class="aside-header">Advertisements</h3>
	<hr class="top-bottom-margin">
	<div class="hide text-center"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>