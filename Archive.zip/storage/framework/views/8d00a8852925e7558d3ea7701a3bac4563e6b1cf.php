<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Impersonate</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
				<form class="form-floating" novalidate="novalidate" action="<?php echo e(route('admin.impersonate.index')); ?>" method="post">
				    <?php echo e(csrf_field()); ?>

				    
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
						<label class="control-label">Email :</label>
						<input name="email" type="text" value="<?php echo e(old('email')); ?>" class="form-control1">
						<?php if($errors->has('email')): ?>
							<span class="help-block"><?php echo e($errors->first('email')); ?></span>
						<?php endif; ?>
					</div>
				    
				    <br>
				    <input type="submit" value="Impersonate" class="btn btn-danger">
			    </form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>