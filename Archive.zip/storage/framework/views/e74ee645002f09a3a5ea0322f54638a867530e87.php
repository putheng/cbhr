<?php $__env->startComponent('mail::message'); ?>

# Password updated

Dear <?php echo e(auth()->user()->name); ?>,

We're just letting you know that your password has changed.<br>
If you didn't request this password change please contact the customer support team.
<br>Or
<a href="<?php echo e(route('password.request')); ?>">reset password</a>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
