<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
	<?php echo $__env->make('layouts.partials.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
        <div id="wrapper">
            <?php echo $__env->make('layouts.partials.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

	<?php echo $__env->make('layouts.partials.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
