<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">

		<div class="xs">
			<h3>Payment Transactions</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
				<p class="text-right">
					<a href="<?php echo e(route('employer.payment.deposit')); ?>">Make a deposit</a>
				</p>
				<br>
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>DATE</th>
							<th>PSP</th>
							<th>AMOUNT</th>
							<th>TRANSACTION</th>
							<th>STATUS</th>
						</tr>
					</thead>
					<tbody>
						<?php if($transactions->count()): ?>
							<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($transaction->created_at->format('l jS \\of F Y h:i:s A')); ?></td>
									<td><?php echo e($transaction->process); ?></td>
									<td>$<?php echo e(number_format($transaction->amount, 2)); ?></td>
									<td style="letter-spacing: 2px;"><?php echo e($transaction->transaction); ?></td>
									<td><?php echo e($transaction->status); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<tr>
								<td class="text-center" colspan="6">
									<span>You don't have any transaction yet.</span> <a href="<?php echo e(route('employer.payment.deposit')); ?>" class="text-success">Make a deposit</a>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>