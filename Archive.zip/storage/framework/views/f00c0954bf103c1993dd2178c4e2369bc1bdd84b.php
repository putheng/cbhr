<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html">Dashboard</a>
				</div>
				<!-- /.navbar-header -->
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown">
						<img src="images/1.png">
						</a>
						<ul class="dropdown-menu">
							<li class="dropdown-menu-header text-center">
								<strong>Settings</strong>
							</li>
							<li class="m_2">
								<a href="#">
								<i class="fa fa-user"></i>
								Profile
								</a>
							</li>
							<li class="m_2">
								<a href="#">
								<i class="fa fa-wrench"></i>
								Settings
								</a>
							</li>
							<li class="m_2">
								<a href="#">
								<i class="fa fa-usd"></i>
								Wallet
								<span class="label label-default">$0.00</span>
								</a>
							</li>
							<li class="m_2">
								<a href="#">
								<i class="fa fa-lock"></i>
								Logout
								</a>
							</li>
						</ul>
					</li>
				</ul>
				<form class="navbar-form navbar-right">
					<input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
				</form>
				<div class="navbar-default sidebar" role="navigation">
					<div class="sidebar-nav navbar-collapse">
						<ul class="nav" id="side-menu">
							<li>
								<a href="index.html">
								<i class="fa fa-dashboard fa-fw nav_icon"></i>
								Dashboard
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fa fa-indent nav_icon"></i>
									Listing<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="graphs.html">Create</a>
									</li>
									<li>
										<a href="typography.html">Publish</a>
									</li>
									<li>
										<a href="typography.html">Unpublish</a>
									</li>
									<li>
										<a href="typography.html">Expired</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-envelope nav_icon"></i>
								Applications<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="inbox.html">Applications</a>
									</li>
									<li>
										<a href="compose.html">Approved</a>
									</li>
									<li>
										<a href="compose.html">Rejected</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-user fa-fw nav_icon"></i>Jobseekers<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="media.html">Purchased</a>
									</li>
									<li>
										<a href="login.html">Browse</a>
									</li>
									<li>
										<a href="login.html">Saved</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-usd nav_icon"></i>
								Payments<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="basic_tables.html">My Wallet</a>
									</li>
									<li>
										<a href="basic_tables.html">Make Deposit</a>
									</li>
									<li>
										<a href="basic_tables.html">Transaction</a>
									</li>
									<li>
										<a href="basic_tables.html">History</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-wrench nav_icon"></i>
								Profile<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="forms.html">Edit</a>
									</li>
									<li>
										<a href="validation.html">Change Password</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="login.html">
								<i class="fa fa-lock fa-fw nav_icon"></i>
								Logout
								</a>
							</li>
						</ul>
					</div>
					<!-- /.sidebar-collapse -->
				</div>
				<!-- /.navbar-static-side -->
			</nav>
			