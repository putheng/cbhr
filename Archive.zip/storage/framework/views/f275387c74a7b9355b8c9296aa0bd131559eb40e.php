<?php $__env->startSection('content'); ?>

<div class="fright">
	<a class="small-tile green-back" href="index.php?category=users&amp;action=new_employer">
		<img class="hide-sm pull-right" width="32" src="<?php echo e(asset('images/icons/default.png')); ?>">
		<h3 class="h3-tile">Add a new employer</h3>
	</a>
</div>
<div class="clear"></div>
<h3>Manage the registered publishers</h3>
<br>
<div style="float:right">
	<form action="index.php" method="post">
		<input type="hidden" name="category" value="users"><input type="hidden" name="action" value="employers">
		Search in 
		<select name="comboSearch" class="table-combo-search">
			<option value="id">id</option>
			<option value="name">Name</option>
			<option value="fbid">Facebook id</option>
			<option value="phone">Phone</option>
		</select>
		<input class="table-search-field" value="" type="text" required="" name="textSearch"> 
		<input type="submit" class="btn btn-default btn-gradient" value=" Search ">
	</form>
</div>
<div class="clear"></div>
<form action="index.php" id="table-form" method="post" enctype="multipart/form-data">
	<div class="table-responsive">
		<table cellpadding="3" cellspacing="0" width="100%" style="border-color:#eeeeee;border-width:1px 1px 1px 1px;border-style:solid">
			<tbody>
				<tr class="table-tr" nowrap="">
					<td class="header-td">id</td>
					<td class="header-td">Name</td>
					<td class="header-td">Facebook ID</td>
					<td class="header-td">Balance</td>
					<td class="header-td">Phone</td>
					<td class="header-td">Active</td>
				</tr>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<tr height="30">
    					<td><?php echo e($user->id); ?></td>
    					<td><?php echo e($user->name); ?></td>
    					<td><?php echo e($user->email); ?></td>
    					<td><?php echo e(number_format($user->usd, 2)); ?></td>
    					<td><?php echo e($user->password); ?></td>
    					<td>
    					    <a href="">
    					        <img border="0" src="<?php echo e(asset('images/active_1.gif')); ?>">
    					    </a>
    				    </td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<br>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>