<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Change your password</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
				<form action="<?php echo e(route('employer.profile.password')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<fieldset>

		                <div class="form-group<?php echo e($errors->has('password_current') ? ' has-error' : ''); ?>">
		                    <label for="password_current" class="control-label">Current password</label>
		                    <input type="password" name="password_current" id="password_current" class="form-control1">
		
		                    <?php if($errors->has('password_current')): ?>
		                        <span class="help-block">
		                            <strong><?php echo e($errors->first('password_current')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                </div>
		                <br>
		
		                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
		                    <label for="password" class="control-label">New password</label>
		                    <input type="password" name="password" id="password" class="form-control1">
		
		                    <?php if($errors->has('password')): ?>
		                        <span class="help-block">
		                            <strong><?php echo e($errors->first('password')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                </div>
		
		                <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
		                    <label for="password_confirmation" class="control-label">New password again</label>
		                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control1">
		
		                    <?php if($errors->has('password_confirmation')): ?>
		                        <span class="help-block">
		                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                </div>
						
						<br>
		                <button type="submit" class="btn btn-info">Change password</button>
					</fieldset>
				</form>
			</div>
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>