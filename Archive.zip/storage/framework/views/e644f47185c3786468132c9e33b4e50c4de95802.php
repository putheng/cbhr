<?php $__env->startSection('title'); ?>
    <title>Cambodia HR | Cambodia’s leading human resources and recruitment site.</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12';
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
<?php if($listings->count()): ?>
    <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="job-wrap">
        	<div class="row">
        		<div class="col-sm-8">
        			<a target="_blank" class="results-job-title-link" href="<?php echo e(route('listing.show', $listing)); ?>">
        				<h4 class="no-margin results-job-title">
                            <?php echo e($listing->title); ?>

                        </h4>
        			</a>
        			<div class="icon-h5">
        				<h5>
        					<span class="glyphicon glyphicon-equalizer"></span> 
        					<?php echo e(optional($listing->company)->name); ?>

        				</h5>
        				<h5>
        					<span class="glyphicon glyphicon-map-marker"></span> 
        					<?php echo e(optional($listing->area)->name); ?>

        				</h5>
        				<h5>
        				    <span class="glyphicon glyphicon-usd"></span>
        				    <?php echo e(optional($listing->salary)->name); ?>

        				</h5>
        			</div>
        			<ul class="results-job-details">
        				<li><?php echo e(optional($listing->category)->name); ?></li>
        				<li><?php echo e(optional($listing->term)->name); ?></li>
        			</ul>
        			<div class="results-job-description">
        				<?php echo e(str_limit($listing->description, 150)); ?> 
        			</div>
        			<div class="clearfix"></div>
        			<br>
        			<div class="icon-h5">
        				<h5>
        				    <span class="glyphicon glyphicon-time"></span>
        				    <?php echo e($listing->created_at->diffForHumans()); ?>

        			    </h5>
        			</div>
        		</div>
        		<div class="col-sm-4">
        			<div class="save-job-link pull-right">
        				<a href="javascript:SaveListing(<?php echo e($listing->id); ?>)" id="save_<?php echo e($listing->id); ?>">
            				Save
            				<img height="13" src="<?php echo e(asset('images/save-small-icon.png')); ?>" alt="Save">
        				</a>
        			</div>
        			<div class="hidden-xs">
        				<div class="save-job-link"><br>Post by<br></div>
        				<?php if(!empty($listing->company->avatarPath())): ?>
            				<div class="hidden-xs">
            					<br>
            					<a href="<?php echo e(route('company.show', $listing->company)); ?>">
            					    <img style="max-height:115px;" class="img-responsive logo-results" src="<?php echo e($listing->company->avatarPath()); ?>" alt="">
            					</a>										
            				</div>
        				<?php else: ?>
            				<p class="text-center">
                            	<span class="feed-company"><?php echo e($listing->company->name); ?>xxx</span>
                            </p>
        				<?php endif; ?>
        			</div>
        			<p class="text-center" style="margin-top: 15px;"><br>
        				<a href="<?php echo e(route('listing.show', $listing)); ?>" class=" underline-link">Job Details</a>
        			</p>
        		</div>
        	</div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php echo e($listings->links()); ?>

<?php else: ?>
    <p class="h3">No listings found.</p>
<?php endif; ?>

        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        				    <span aria-hidden="true">&times;</span>
        				</button>
        				<h4 class="modal-title" id="myModalLabel">
        				 ចង់បានការងារល្អប្រាក់ខែខ្ពស់មេនទេ
        				 
        				 </h4>
        			</div>
        			<div class="modal-body text-center">
        			    <p>ចុច Like Page ដើម្បីទទួលបានដំណឹងជ្រើសរើសបុគ្គលិក ច្រើនជាង 200​​ តំណែងរាល់ថ្ងៃ</p>
                        <div class="fb-page" 
                          data-href="https://www.facebook.com/CambodiaHRcom/"
                          data-hide-cover="false"
                          data-adapt-container-width="true" 
                          data-show-facepile="true"></div>
        			</div>
        		</div>
        	</div>
        </div>
        
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <di class="hidden-xs hidden-sm">
	    <?php echo $__env->make('home.partials.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </di>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>