<?php $__env->startSection('css'); ?>
	<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>
				Create Listing 
				<?php if($id): ?>
					<small><a href="<?php echo e(route('admin.listing.create', ['id' => ($id + 1)])); ?>">Next</a></small>
				<?php endif; ?>
			</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
				<form class="form-floating" novalidate="novalidate" action="<?php echo e(route('admin.listing.create.store')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<fieldset>
						
						<div class="form-group">
							<img src="<?php echo e($company['logo']); ?>">
							<input type="hidden" name="logoimg" value="<?php echo e($company['logo']); ?>">
						</div>
						
						<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
							<label class="control-label">Title :</label>
							<input name="title" type="text" value="<?php echo e($listing['title']); ?>" class="form-control1">
							<?php if($errors->has('title')): ?>
								<span class="help-block"><?php echo e($errors->first('title')); ?></span>
							<?php endif; ?>
						</div>
						<input type="hidden" name="lastid" value="<?php echo e(request('id')); ?>">
						
						<?php echo $__env->make('users.admin.listings.partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
						<div class="form-group<?php echo e($errors->has('requirement') ? ' has-error' : ''); ?>">
							<label class="control-label">Requirements :</label>
							<textarea name="requirement" class="form-control1" style="height:100px;"><?php echo str_replace("<br/>", "\n", $listing['requirement']); ?></textarea>
							<?php if($errors->has('requirement')): ?>
								<span class="help-block"><?php echo e($errors->first('requirement')); ?></span>
							<?php endif; ?>
						</div>
						
						<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
							<label class="control-label">Description :</label>
							<textarea name="description" class="form-control1" style="height:100px;"><?php echo str_replace("<br/>", "\n", $listing['description']); ?></textarea>
							<?php if($errors->has('description')): ?>
								<span class="help-block"><?php echo e($errors->first('description')); ?></span>
							<?php endif; ?>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('start') ? ' has-error' : ''); ?>">
									<label class="control-label">Start Date : <?php echo e($listing['start']); ?></label>
									<input name="start" type="text" class="form-control1" value="<?php echo e(post_start()); ?>">
									<?php if($errors->has('start')): ?>
										<span class="help-block"><?php echo e($errors->first('start')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('closing') ? ' has-error' : ''); ?>">
									<label class="control-label">Closing Date : <?php echo e($listing['closing']); ?></label>
									<input name="closing" type="text" value="<?php echo e(post_expire()); ?>" class="form-control1">
									<?php if($errors->has('closing')): ?>
										<span class="help-block"><?php echo e($errors->first('closing')); ?></span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<hr>
						
						<div class="form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
							<label class="control-label">Company :</label>
							<input name="company" type="text" value="<?php echo e($company['name']); ?>" class="form-control1">
							<?php if($errors->has('company')): ?>
								<span class="help-block"><?php echo e($errors->first('company')); ?></span>
							<?php endif; ?>
						</div>
						
						<div class="row">
							<div class="col-md-6">
								<div class="form-group<?php echo e($errors->has('person') ? ' has-error' : ''); ?>">
									<label class="control-label">Person :</label>
									<input name="person" type="text" class="form-control1" value="<?php echo e($company['person']); ?>">
									<?php if($errors->has('person')): ?>
										<span class="help-block"><?php echo e($errors->first('person')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
									<label class="control-label">Email :</label>
									<input name="email" type="text" class="form-control1" value="<?php echo e($company['email']); ?>">
									<?php if($errors->has('email')): ?>
										<span class="help-block"><?php echo e($errors->first('email')); ?></span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('industry') ? ' has-error' : ''); ?>">
									<label class="control-label">Industry : <?php echo e($company['industry']); ?></label>
									<select name="industry" class="form-control1">
										<?php $__currentLoopData = \App\Models\Industry::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($company['industry'] == $child->name): ?>
												<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php else: ?>
												<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('industry')): ?>
										<span class="help-block"><?php echo e($errors->first('industry')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
									<label class="control-label">Company Type : <?php echo e($company['type']); ?></label>
									<select name="type" class="form-control1">
										<?php $__currentLoopData = \App\Models\CompanyType::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($company['type'] == $child->name): ?>
												<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php else: ?>
												<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('type')): ?>
										<span class="help-block"><?php echo e($errors->first('type')); ?></span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('employee') ? ' has-error' : ''); ?>">
									<label class="control-label">Employee : <?php echo e($company['employee']); ?></label>
									<select name="employee" class="form-control1">
										<option value="<?php echo e($company['employee']); ?>"><?php echo e($company['employee']); ?></option>
										<?php $__currentLoopData = \App\Models\EmployeeType::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($company['type'] == $child->name): ?>
												<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php else: ?>
												<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('employee')): ?>
										<span class="help-block"><?php echo e($errors->first('employee')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
									<label class="label-control">Phone:</label>
									<input type="text" class="form-control1" name="phone" value="<?php echo e($company['phone']); ?>">
									<?php if($errors->has('phone')): ?>
				                        <div class="help-block">
				                            <?php echo e($errors->first('phone')); ?>

				                        </div>
				                    <?php endif; ?>
								</div>
							</div>
						</div>
						
						<div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
							<label class="label-control">Address:</label>
							<input type="text" class="form-control1" name="address" value="<?php echo e($company['address']); ?>">
							<?php if($errors->has('address')): ?>
		                        <div class="help-block">
		                            <?php echo e($errors->first('address')); ?>

		                        </div>
		                    <?php endif; ?>
						</div>
						
						<div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
							<label class="label-control">Website:</label>
							<input type="text" class="form-control1" name="website" value="<?php echo e($company['website']); ?>">
							<?php if($errors->has('website')): ?>
		                        <div class="help-block">
		                            <?php echo e($errors->first('website')); ?>

		                        </div>
		                    <?php endif; ?>
						</div>
						
						
						
						<div class="form-group<?php echo e($errors->has('companyDescription') ? ' has-error' : ''); ?>">
							<label class="label-control">Description:</label>
							<textarea class="form-control1" name="companyDescription"><?php echo str_replace("<br/>", "\n", $company['description']); ?></textarea>
							<?php if($errors->has('companyDescription')): ?>
		                        <div class="help-block">
		                            <?php echo e($errors->first('companyDescription')); ?>

		                        </div>
		                    <?php endif; ?>
		                    <input type="hidden" value="<?php echo e($company['logo']); ?>" name="logo">
						</div>
						
						<div class="form-group">
							<button type="submit" class="btn btn-primary">Submit</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
					</fieldset>
				</form>
			</div>
					
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<script type="text/javascript" src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<?php if(session('success')): ?>
	<script type="text/javascript">
		$('select').select2();
		
		$(document).ready(function(){
			setTimeout( function () {
		        $('.form-floatingxx').submit();
		    }, 1000);
			
		});
	</script>
<?php endif; ?>
<?php if(session('error')): ?>
	<script type="text/javascript">
		$('select').select2();
		
		$(document).ready(function(){
			setTimeout( function () { 
		        $('.form-floatingxx').submit();
		    }, 500);
			
		});
	</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>