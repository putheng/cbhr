<?php $__env->startSection('content'); ?>

<div class="page-wrap">
	<h3>In order to sign up, please fill the form below</h3>
	<form id="main" class="employers_registration" action="<?php echo e(route('register')); ?>" method="post">
	     <?php echo e(csrf_field()); ?>

		<br>
		<fieldset>
			<ol>
				<li<?php echo $errors->has('name') ? ' class="has-error"' : ''; ?>>
                    <label>Name:</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                        <div class="response">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li<?php echo $errors->has('email') ? ' class="has-error"' : ''; ?>>
					<label>Email:</label>
					<input type="text" name="email" value="<?php echo e(old('email')); ?>">
					<?php if($errors->has('email')): ?>
                        <div class="response">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li<?php echo $errors->has('password') ? ' class="has-error"' : ''; ?>>
					<label>Password:</label>
					<input type="password" name="password">
					<?php if($errors->has('password')): ?>
                        <div class="response">
                            <?php echo e($errors->first('password')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li>
					<label>Confirm Password:</label>
					<input type="password" name="password_confirmation">
				</li>
				
				<li<?php echo $errors->has('company') ? ' class="has-error"' : ''; ?>>
					<label>Company:</label>
					<input type="text" name="company" value="<?php echo e(old('company')); ?>">
					<?php if($errors->has('company')): ?>
                        <div class="response">
                            <?php echo e($errors->first('company')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li<?php echo $errors->has('description') ? ' class="has-error"' : ''; ?>>
					<label>Description:</label>
					<textarea name="description" cols="32" rows="3"><?php echo e(old('description')); ?></textarea>
					<?php if($errors->has('description')): ?>
                        <div class="response">
                            <?php echo e($errors->first('description')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li<?php echo $errors->has('address') ? ' class="has-error"' : ''; ?>>
					<label>Address:</label>
					<textarea name="address" cols="32" rows="3"><?php echo e(old('address')); ?></textarea>
					<?php if($errors->has('address')): ?>
                        <div class="response">
                            <?php echo e($errors->first('address')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li<?php echo $errors->has('phone') ? ' class="has-error"' : ''; ?>>
					<label>Phone:</label>
					<input type="text" name="phone" id="phone" value="">
					<?php if($errors->has('phone')): ?>
                        <div class="response">
                            <?php echo e($errors->first('phone')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				
				<li>
					<label>Website:</label>
					<input type="text" name="website" id="website" value="">
				</li>
				
				<li>
					<input type="checkbox" name="newsletter" value="on">
					I would like to subscribe to the cambodiahr.com newsletter							
				</li>
			</ol>
		</fieldset>
		<div class="clearfix"></div>
		<br>
		<div class="row">
			<div class="col-md-4 pull-right text-center">
				<button type="submit" class="btn btn-primary" style="padding:10px 45px;">Submit</button>
				<br><br>
				<p class="h5">Or <a href="<?php echo e(url('/login')); ?>" class="text-primary">Login Now</a></p>
			</div>
			<div class="clearfix"></div>
		</div>
		<br>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>