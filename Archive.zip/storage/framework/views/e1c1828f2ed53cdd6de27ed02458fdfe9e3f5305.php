<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Make a deposit to your wallet</h3>
			<div class="well1 white">
				<form action="<?php echo e(route('employer.payment.deposit')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<h5 class="<?php echo e($errors->has('processor') ? 'text-danger' : 'text-success'); ?>">Processor </h5>
					<hr style="margin-top:0;"/>
					<ul class="no-margin list-inline processor">
						<?php $__currentLoopData = \App\Models\Processor::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li>
								<input <?php echo old('processor') ==  $processor->id ? 'checked' : ''; ?> id="<?php echo e($processor->name); ?>" type="radio" name="processor" value="<?php echo e($processor->id); ?>" class="hidden style">
								<label for="<?php echo e($processor->name); ?>">
									<img src="/images/checking.png" class="checking">
									<img src="/images/<?php echo e(strtolower($processor->name)); ?>.png" width="70" height="70" class="opacity">
								</label>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<?php if($errors->has('processor')): ?>
						<span class="help-block text-danger"><?php echo e($errors->first('processor')); ?></span>
					<?php endif; ?>
					<br><br>
					<h5 class="<?php echo e($errors->has('amount') ? 'text-danger' : 'text-success'); ?>">Amount</h5>
					<hr style="margin-top:0;"/>
					<div class="row">
						<div class="col-sm-7">
							<div class="input-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
								<span class="input-group-addon">$</span>
								<input value="<?php echo e(old('amount')); ?>" style="letter-spacing: 3px; font-weight: bold;" autocomplete="off" placeholder="00" type="text" class="form-control1" name="amount">
								<span class="input-group-addon">.00</span>
							</div>
							<?php if($errors->has('amount')): ?>
								<span class="help-block text-danger"><?php echo e($errors->first('amount')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<br>
					
					<div class="form-group">
						<label class="control-label h5 <?php echo e($errors->has('transaction') ? 'text-danger' : 'text-success'); ?>">Transaction Code</label>
						<hr style="margin-top:0;"/>
						<div class="row">
							<div class="col-sm-7">
								<input value="<?php echo e(old('transaction')); ?>" style="letter-spacing: 10px; font-weight: bold;" autocomplete="off" name="transaction" type="text" class="form-control1" placeholder="00000000">
								
								<?php if($errors->has('transaction')): ?>
									<span class="help-block text-danger"><?php echo e($errors->first('transaction')); ?></span>
								<?php endif; ?>
							</div>
						</div>
					</div>
					
					<br>
					
					<div class="form-group hidden">
						<label class="control-label h5 text-success">Recipient</label>
						<hr style="margin-top:0;"/>
						<div class="row">
							<div class="col-sm-7">
								<input style="letter-spacing: 3px; font-weight: bold;" disabled="disabled" placeholder="093259984" id="disabledInput" type="number" class="form-control1" name="recipient">
							</div>
						</div>
					</div>
						
					<hr>
					
					<p>
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-arrow-circle-o-down"></i>
							&nbsp;&nbsp;SUBMIT&nbsp;&nbsp;
						</button>
					</p>
				
				</form>
			</div>
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>