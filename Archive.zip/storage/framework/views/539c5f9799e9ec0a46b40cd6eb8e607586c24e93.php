<div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
	<label class="control-label">Category : <?php echo e($listing['category']); ?></label>
	<select name="category" class="form-control1">
		<option value="<?php echo e($listing['category']); ?>"><?php echo e($listing['category']); ?></option>
		<!--<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
			
		<!--	<optgroup label="<?php echo e($category->name); ?>">-->
		<!--		<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>-->
		<!--		<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
		<!--			<?php if($listing['category'] == $child->name): ?>-->
		<!--				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>-->
		<!--			<?php else: ?>-->
		<!--				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>-->
		<!--			<?php endif; ?>-->
		<!--		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
		<!--	</optgroup>-->
		<!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
	</select>
	<?php if($errors->has('category')): ?>
		<span class="help-block"><?php echo e($errors->first('category')); ?></span>
	<?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('term') ? ' has-error' : ''); ?>">
	<label class="control-label">Job Term : <?php echo e($listing['term']); ?></label>
	<select name="term" class="form-control1">
		<?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($listing['term'] == $child->name): ?>
				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php else: ?>
				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('term')): ?>
		<span class="help-block"><?php echo e($errors->first('term')); ?></span>
	<?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
	<label class="control-label">Career Level : <?php echo e($listing['level']); ?></label>
	<select name="level" class="form-control1">
		<?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($listing['level'] == $child->name): ?>
				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php else: ?>
				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('level')): ?>
		<span class="help-block"><?php echo e($errors->first('level')); ?></span>
	<?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('education') ? ' has-error' : ''); ?>">
	<label class="control-label">Education : <?php echo e($listing['education']); ?></label>
	<select name="education" class="form-control1">
		<?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($listing['education'] == $child->name): ?>
				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php else: ?>
				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('education')): ?>
		<span class="help-block"><?php echo e($errors->first('education')); ?></span>
	<?php endif; ?>
</div>

<div class="row">
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('salary') ? ' has-error' : ''); ?>">
			<label class="control-label">Salary : <?php echo e($listing['salary']); ?></label>
			<select name="salary" class="form-control1">
				<option value="2">$200-$500</option>
				<?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($listing['salary'] == $child->name): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('salary')): ?>
				<span class="help-block"><?php echo e($errors->first('salary')); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('experience') ? ' has-error' : ''); ?>">
			<label class="control-label">Years of Experience : <?php echo e($listing['experience']); ?></label>
			<select name="experience" class="form-control1">
				<?php if($listing['experience'] > 1): ?>
					<option value="3">2+ to 5</option>
				<?php elseif($listing['experience'] > 5): ?>
					<option value="4">5+ to 7</option>
				<?php else: ?>
					<option value="2">1+ to 2</option>
				<?php endif; ?>
				<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('experience')): ?>
				<span class="help-block"><?php echo e($errors->first('experience')); ?></span>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('age') ? ' has-error' : ''); ?>">
			<label class="control-label">Age : (18 - 35...) <?php echo e($listing['age']); ?></label>
			<select name="age" class="form-control1">
				<option value="2">18-35</option>
				<?php $__currentLoopData = $age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('age')): ?>
				<span class="help-block"><?php echo e($errors->first('age')); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
			<label class="control-label">Gender : <?php echo e($listing['gender']); ?></label>
			<select name="gender" class="form-control1">
				<option value="3">Male-Female</option>
				<?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($listing['gender'] == $child->name): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('gender')): ?>
				<span class="help-block"><?php echo e($errors->first('gender')); ?></span>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="form-group<?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
	<label class="control-label">Locations : <?php echo e($listing['location']); ?> </label>
	<select name="location" class="form-control1">
		<option value="<?php echo e($listing['location']); ?>"><?php echo e($listing['location']); ?></option>
		<!--<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
		<!--	<optgroup label="<?php echo e($area->name); ?>">-->
		<!--		<option value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>-->
		<!--		<?php $__currentLoopData = $area->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
		<!--			<?php if($listing['location'] == $child->name): ?>-->
		<!--				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>-->
		<!--			<?php else: ?>-->
		<!--				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>-->
		<!--			<?php endif; ?>-->
		<!--		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
		<!--	</optgroup>-->
		<!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
	</select>
	<?php if($errors->has('location')): ?>
		<span class="help-block"><?php echo e($errors->first('location')); ?></span>
	<?php endif; ?>
</div>