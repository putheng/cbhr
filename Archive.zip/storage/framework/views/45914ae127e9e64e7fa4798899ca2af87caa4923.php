<!DOCTYPE html>
<html>
    <head>
        <?php echo $__env->make('home.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
    </head>
    <body>
       <div id="wrapper"> 
        <?php echo $__env->make('home.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <div class="top-line"></div>
        
        <?php echo $__env->make('home.partials.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <div class="container main-container">
            <div class="row">
                <div class="col-md-8 min-height-400">
	            <!-- Main -->
                    <?php echo $__env->yieldContent('content'); ?>
                    
                <!-- End Main -->
                </div>
                <div class="col-md-4">
                    <?php echo $__env->yieldContent('sidebar'); ?>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <br>
        <?php echo $__env->make('home.partials.companyCarousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.mainFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.footerBottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.loginDialog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.applyModal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script type="text/javascript" src="<?php echo e(asset('js/carousel.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/functions.js?v=5')); ?>"></script>
        <?php echo $__env->yieldContent('script'); ?>
        </div>
    </body>
</html>