    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
	<!-- Metis Menu Plugin JavaScript -->
	<script src="<?php echo e(asset('js/emp/metisMenu.min.js')); ?>"></script>
	<!-- Graph JavaScript -->
	<script src="<?php echo e(asset('js/emp/custom.js')); ?>"></script>