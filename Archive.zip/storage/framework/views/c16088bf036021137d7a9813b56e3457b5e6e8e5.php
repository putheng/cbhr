<?php $__env->startSection('content'); ?>

<div class="page-wrap">
	<h3>In order to sign in, please fill the form below</h3>
	<br>
	<form id="main" class="employers_registration" action="<?php echo e(route('login')); ?>" method="post">
		<br>
		<fieldset>
			<ol>
				<li<?php echo $errors->has('email') ? ' class="has-error"' : ''; ?>>
					<label>Email: (*) </label>
					<input type="text" name="email" value="<?php echo e(old('email')); ?>">
					<?php if($errors->has('email')): ?>
                        <div class="response">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				<li<?php echo $errors->has('password') ? ' class="has-error"' : ''; ?>>
					<label>Password: (*) </label>
					<input type="password" name="password" id="password">
					<?php if($errors->has('password')): ?>
                        <div class="response">
                            <?php echo e($errors->first('password')); ?>

                        </div>
                    <?php endif; ?>
				</li>
				<li>
					<input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
					Remember me						
				</li>
			</ol>
		</fieldset>
		<div class="clearfix"></div>
		<br>
		<div class="emre-response text-center"></div>
		<div class="row">
			<div class="col-md-12 pull-right text-center">
			    <?php echo e(csrf_field()); ?>

				<button type="submit" class="btn btn-primary" style="padding:10px 45px;">Login</button>
				<br>
				<p class="h5">
					Or <a href="<?php echo e(url('/register')); ?>" class="text-primary">Create Account</a>
				</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="row">
			<div class="col-md-12 text-center">

				<br>
				<a href="<?php echo e(route('facebook.login')); ?>" class="btn btn-primary">
					Login with Facebook as Publisher
				</a>
			</div>
		</div>
		<div class="clearfix"></div>		
		<br>
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>