<div id="companies-carousel">
	<div class="container text-center">
		<script type="text/javascript">
		
		var companies_carousel_itemList = 
				<?php echo $companyCarousel; ?>

			;
		</script>
		
		<h3 class="bottom-margin-5">Featured Companies</h3>
		<div id="ads-rotator">
		<br>
			<div id="wrap">
				<div class=" jcarousel-skin-ie7">
					<div class="jcarousel-container jcarousel-container-horizontal" style="position: relative; display: block;">
						<div class="jcarousel-clip jcarousel-clip-horizontal" style="position: relative;">
							<ul id="companies_carousel" class="jcarousel-list jcarousel-list-horizontal" style="overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: 0px; width: 2577px;">
							</ul>
						</div>
						<div class="jcarousel-prev jcarousel-prev-horizontal jcarousel-prev-disabled jcarousel-prev-disabled-horizontal" disabled="disabled" style="display: block;"></div>
						<div class="jcarousel-next jcarousel-next-horizontal" style="display: block;"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="clear"></div>	
	</div>
</div>