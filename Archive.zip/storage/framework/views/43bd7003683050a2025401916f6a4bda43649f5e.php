<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">

		<div class="xs">
			<h3>Select listings to post</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
			    <div class="table-responsive">
    				<table class="table">
    					<thead>
    						<tr>
    							<th>ID</th>
    							<th>Title</th>
    							<th>Category</th>
    							<th>Company</th>
    							<th class="text-center">Action</th>
    						</tr>
    					</thead>
    					<tbody>
    						<?php if($listings->count()): ?>
    							<?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    								<tr>
    									<td><?php echo e($listing->id); ?></td>
    									<td><?php echo e($listing->title); ?></td>
    									<td><?php echo e($listing->category->name); ?></td>
    									<td><?php echo e($listing->company->name); ?></td>
    									<td class="text-center">
    									    <a onclick="event.preventDefault(); document.getElementById('listings-post-form-<?php echo e($listing->id); ?>').submit();" href="#" class="btn btn-info btn-sm">Post</a>
	    									<form class="hidden" action="<?php echo e(route('publisher.promote.store', [$listing])); ?>" method="post" id="listings-post-form-<?php echo e($listing->id); ?>">
											    <?php echo e(csrf_field()); ?>

											</form>
    									</td>
    								</tr>
    							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						<?php else: ?>
    							<tr>
    								<td class="text-center" colspan="6">
    									<span>No listings found.</span>
    								</td>
    							</tr>
    						<?php endif; ?>
    					</tbody>
    				</table>
				</div><br>
				<div class="text-right">
				    <?php echo e($listings->links()); ?>

				</div>
			</div>
			
		</div>
		
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publisher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>