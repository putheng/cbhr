<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">

		<div class="xs">
			<h3>Publish Listings</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
				<table class="table">
					<thead>
						<tr>
							<th>#</th>
							<th>Title</th>
							<th>Location</th>
							<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php if($listings->count()): ?>
							<?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th scope="row"><?php echo e($listing->id); ?></th>
									<td>
										<a target="_blank" href="<?php echo e(route('listing.show', $listing)); ?>"><?php echo e($listing->title); ?></a>
										<small>(<?php echo e($listing->created_at->diffForHumans()); ?>)</small>
									</td>
									<td><?php echo e($listing->area->parent->name); ?> &nbsp; > &nbsp;
									<?php echo e($listing->area->name); ?></td>
									<td class="text-center">
										<ul class="list-inline no-margin">
											<li><a href="<?php echo e(route('employer.listing.edit', $listing)); ?>">Edit</a></li>
											<li><a onclick="event.preventDefault(); document.getElementById('listings-destroy-form-<?php echo e($listing->id); ?>').submit();" href="#">Delete</a></li>
											<form action="<?php echo e(route('employer.listing.destroy', [$listing])); ?>" method="post" id="listings-destroy-form-<?php echo e($listing->id); ?>">
											    <?php echo e(csrf_field()); ?>

											    <?php echo e(method_field('DELETE')); ?>

											</form>
										</ul>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>	
							<tr>
								<td colspan="4" class="text-center">
									No listings found.
									<a href="<?php echo e(route('employer.listing.create')); ?>">Create Listing</a>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<?php echo e($listings->links()); ?>

		</div>

		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>