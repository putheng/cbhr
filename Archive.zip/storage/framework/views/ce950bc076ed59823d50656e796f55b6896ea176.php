<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>All Transactions</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<div class="well1 white">
				<div class="row wrapper text-center">
    				<div class="col-xs-6 col-md-6 b-r b-light">
    					<span class="h3 text-danger font-bold m-t m-b-xs block">
    						$<?php echo e(number_format(auth()->user()->usd, 3)); ?>

    					</span>
    					<small class="h5 text-muted m-b help-block">
    					    Available Earnings
    					</small>
    				</div>
    				<div class="col-xs-6 col-md-6 b-r b-light">
    					<span class="h3 text-danger font-bold m-t m-b-xs block">
    						$0.00
    					</span>
    					<small class="h5 text-muted m-b help-block">
    					    Last Pay Period
    					</small>
    					
    				</div>
    			</div>
    			<br><hr>
    	        <div class="table-responsive">
    	        	<table class="table table-striped">
    	        		<thead>
    	        			<th>ID</th>
    	        			<th>PSP</th>
    	        			<th>Amount</th>
    	        			<th>Date</th>
    	        			<th>Status</th>
    	        		</thead>
    	        		<tbody>
    	        			<?php if($withdraws->count()): ?>
    	        				<?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    	        		<tr>
			    	        			<td><?php echo e($withdraw->id); ?></td>
			    	        			<td><?php echo e($withdraw->processor); ?></td>
			    	        			<td><?php echo e($withdraw->amounts); ?></td>
			    	        			<td><?php echo e($withdraw->created); ?></td>
			    	        			<td><?php echo e($withdraw->withdrawStatus); ?></td>
			    	        		</tr>
		    	        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	        			<?php else: ?>
    	        				<tr>
    	        					<td colspan="5" class="text-center">
    	        						You don't have any payment request yet.
    	        						<a href="<?php echo e(route('publisher.withdraw.index')); ?>">Request a payment</a>
    	        					</td>
    	        				</tr>
    	        			<?php endif; ?>
    	        		</tbody>
    	        	</table>
    	        </div>
    	        <br>
    			<?php echo e($withdraws->links()); ?>

			</div>
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publisher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>