<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">
						<i class="fa fa-home"></i>
						Dashboard
					</a>
				</div>
				<!-- /.navbar-header -->
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown">
						<img src="<?php echo e(request()->user()->avatarPath() != null ? request()->user()->avatarPath() : '/images/company-placeholder-300x300.png'); ?>">
						</a>
						<ul class="dropdown-menu">
							<li class="dropdown-menu-header text-center">
								<strong>Welcome,</strong> <?php echo e(auth()->user()->name); ?>

							</li>
							<li class="m_2">
								<a href="<?php echo e(route('employer.listing.published')); ?>">
									<i class="fa fa-indent"></i>
									Listing <span class="label label-default">(<?php echo e($liveListings); ?>)</span>
								</a>
							</li>
							<li class="m_2">
								<a href="<?php echo e(route('employer.payment.show')); ?>">
									<i class="fa fa-usd"></i>
									Wallet
									<span class="label label-default">$<?php echo e(number_format(auth()->user()->usd, 2)); ?></span>
								</a>
							</li>
							<li class="m_2">
								<a href="<?php echo e(route('employer.profile.show')); ?>">
									<i class="fa fa-wrench"></i>
									Settings
								</a>
							</li>
							<li class="m_2">
								<a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
									<i class="fa fa-lock"></i>
									Logout
								</a>
								<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
							</li>
							<?php if (\Illuminate\Support\Facades\Blade::check('impersonating')): ?>
							<li class="m_2">
								<a onclick="event.preventDefault();
                                            document.getElementById('stop-impersonating').submit();"
                                            href="#">
									<i class="fa fa-user"></i>
									Stop impersonating
								</a>
								<form id="stop-impersonating" action="<?php echo e(route('stop.impersonating')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                </form>
							</li>
							<?php endif; ?>
						</ul>
					</li>
				</ul>
				<form class="navbar-form navbar-right">
					<input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
				</form>
				<div class="navbar-default sidebar" role="navigation">
					<div class="sidebar-nav navbar-collapse">
						<ul class="nav" id="side-menu">
							<li>
								<a href="<?php echo e(route('employer.index')); ?>">
								<i class="fa fa-dashboard fa-fw nav_icon"></i>
								Dashboard
								</a>
							</li>
							<li>
								<a href="#">
									<i class="fa fa-indent nav_icon"></i>
									Listings<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?php echo e(route('employer.listing.create')); ?>">Create</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.listing.published')); ?>">Publish (<?php echo e($liveListings); ?>)</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.listing.unpublished')); ?>">Unpublish (<?php echo e($notLiveListings); ?>)</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.listing.expired')); ?>">Expired (<?php echo e($expiredListings); ?>)</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-envelope nav_icon"></i>
								Applications<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?php echo e(route('employer.application.show')); ?>">Applications</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.application.approved')); ?>">Approved</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.application.rejected')); ?>">Rejected</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-user fa-fw nav_icon"></i>Jobseekers<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?php echo e(route('employer.resume.saved')); ?>">Saved</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.resume.browse')); ?>">Browse</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.resume.search')); ?>">Search</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.resume.purchased')); ?>">Purchased</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-usd nav_icon"></i>
								Payments<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?php echo e(route('employer.payment.wallet')); ?>">My Wallet</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.payment.deposit')); ?>">Deposit</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.payment.show')); ?>">Transactions</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="#">
								<i class="fa fa-wrench nav_icon"></i>
								Settings<span class="fa arrow"></span>
								</a>
								<ul class="nav nav-second-level">
									<li>
										<a href="<?php echo e(route('employer.profile.show')); ?>">Profile</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.profile.company')); ?>">Company</a>
									</li>
									<li>
										<a href="<?php echo e(route('employer.profile.password')); ?>">Password</a>
									</li>
								</ul>
								<!-- /.nav-second-level -->
							</li>
							<li>
								<a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
								<i class="fa fa-lock fa-fw nav_icon"></i>
								Logout
								</a>
							</li>
						</ul>
					</div>
					<!-- /.sidebar-collapse -->
				</div>
				<!-- /.navbar-static-side -->
			</nav>
			