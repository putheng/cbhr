<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Profile</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
				<form action="<?php echo e(route('employer.profile.show')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<fieldset>
						<avatar-upload endpoint="<?php echo e(route('account.avatar.store')); ?>" send-as="image" current-avatar="<?php echo e(Auth::user()->avatarPath()); ?>"></avatar-upload>
						<br>
		                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
		                    <label for="name" class="control-label">Name</label>
		                    <input type="text" name="name" id="name" class="form-control1" value="<?php echo e(old('name', auth()->user()->name)); ?>">
		
		                    <?php if($errors->has('name')): ?>
		                        <span class="help-block">
		                            <strong><?php echo e($errors->first('name')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                </div>
		
		                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
		                    <label for="email" class="control-label">Email</label>
		                    <input type="text" name="email" id="email" class="form-control1" value="<?php echo e(old('email', auth()->user()->email)); ?>">
		
		                    <?php if($errors->has('email')): ?>
		                        <span class="help-block">
		                            <strong><?php echo e($errors->first('email')); ?></strong>
		                        </span>
		                    <?php endif; ?>
		                </div>
		
		                <button type="submit" class="btn btn-info">Update</button>
						
					</fieldset>
				</form>
			</div>
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>