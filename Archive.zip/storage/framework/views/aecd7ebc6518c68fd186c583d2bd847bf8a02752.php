    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<script type="application/x-javascript">
		addEventListener(
			"load", 
			function() {
				setTimeout(hideURLbar, 0); 
			},
			false
		);
		
		function hideURLbar(){
			window.scrollTo(0, 1);
		} 
		
		window.Laravel = <?php echo json_encode([
	        'csrfToken' => csrf_token(),
	    ]); ?>;
		</script>
	<!-- Bootstrap Core CSS -->
	<link href="<?php echo e(asset('css/emp/bootstrap.min.css')); ?>" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
	<link href="<?php echo e(asset('css/emp/lines.css')); ?>" rel='stylesheet' type='text/css' />
	<link href="<?php echo e(asset('css/emp/font-awesome.css')); ?>" rel="stylesheet">
	<!----webfonts--->
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
	<!---//webfonts--->  

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
	<!-- Nav CSS -->
	<link href="<?php echo e(asset('css/emp/custom.css')); ?>" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="<?php echo e(asset('css/emp/style.css')); ?>?v=<?php echo e(time()); ?>" rel='stylesheet' type='text/css' />
