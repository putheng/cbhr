<!DOCTYPE html>
<html>
    <head>
        
        <?php echo $__env->make('home.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <title>Cambodia HR | Cambodia’s leading human resources and recruitment site.</title>

    </head>
    <body>
       <div id="wrapper"> 
        <?php echo $__env->make('home.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <div class="top-line"></div>
        
        <?php echo $__env->make('home.partials.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <div class="container main-container">
            <div class="row">
                
                <div class="col-md-4 pull-right hide-sm " id="filter" >
                     <?php echo $__env->make('home.partials.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-8 min-height-400 pull-left">
                <?php if($listings->count()): ?>
                
                <h2>
                    About <b><?php echo e($listings->total()); ?></b> results
                
                    <div class="pull-right visible-xs visible-sm menu-top-margin">
                    	<a href="javascript:ShowHide('filter')" class="expand_menu_link">
                    		<img src="<?php echo e(asset('images/filter-gears.png')); ?>" alt="expand menu">
                    		
                    	</a>
                    </div>
                </h2>
                
                <hr>
                    <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="job-wrap">
                        	<div class="row">
                        		<div class="col-sm-8">
                        			<a target="_blank" class="results-job-title-link" href="<?php echo e(route('listing.show', $listing)); ?>">
                        				<h4 class="no-margin results-job-title"><?php echo e($listing->title); ?></h4>
                        			</a>
                        			<div class="icon-h5">
                        				<h5>
                        					<span class="glyphicon glyphicon-equalizer"></span> 
                        					<?php echo e($listing->company->name); ?>

                        				</h5>
                        				<h5>
                        					<span class="glyphicon glyphicon-map-marker"></span> 
                        					<?php echo e(optional($listing->area->parent)->name); ?> &raquo; <?php echo e($listing->area->name); ?>

                        				</h5>
                        				<h5>
                        				    <span class="glyphicon glyphicon-usd"></span>
                        				    <?php echo e($listing->salary->name); ?>

                        				</h5>
                        			</div>
                        			<ul class="results-job-details">
                        				<li><?php echo e($listing->category->name); ?></li>
                        				<li><?php echo e($listing->term->name); ?></li>
                        			</ul>
                        			<div class="results-job-description">
                        				<?php echo e(str_limit($listing->description, 150)); ?> 
                        			</div>
                        			<div class="clearfix"></div>
                        			<br>
                        			<div class="icon-h5">
                        				<h5>
                        				    <span class="glyphicon glyphicon-time"></span>
                        				    <?php echo e($listing->created_at->diffForHumans()); ?>

                        			    </h5>
                        			</div>
                        		</div>
                        		<div class="col-sm-4">
                        			<div class="save-job-link pull-right">
                        				<a href="javascript:SaveListing(<?php echo e($listing->id); ?>)" id="save_<?php echo e($listing->id); ?>">
                            				Save
                            				<img height="13" src="<?php echo e(asset('images/save-small-icon.png')); ?>" alt="Save">
                        				</a>
                        			</div>
                        			<div class="hidden-xs">
                        				<div class="save-job-link"><br>Post by<br></div>
                        				<?php if(!empty($listing->company->avatarPath())): ?>
                            				<div class="hidden-xs">
                            					<br>
                            					<a href="<?php echo e(route('company.show', $listing->company)); ?>">
                            					    <img style="max-height:115px;" class="img-responsive logo-results" src="<?php echo e($listing->company->avatarPath()); ?>" alt="">
                            					</a>										
                            				</div>
                        				<?php else: ?>
                            				<p class="text-center">
                                            	<span class="feed-company"><?php echo e($listing->company->name); ?></span>
                                            </p>
                        				<?php endif; ?>
                        			</div>
                        			<p class="text-center" style="margin-top: 15px;"><br>
                        				<a href="<?php echo e(route('listing.show', $listing)); ?>" class=" underline-link">Job Details</a>
                        			</p>
                        		</div>
                        	</div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php echo e($listings->links()); ?>

                <?php else: ?>
                    <p class="h3">No listings found.</p>
                <?php endif; ?>


                <!-- End Main -->
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <br>
        <?php echo $__env->make('home.partials.companyCarousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.mainFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.footerBottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.loginDialog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('home.partials.applyModal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script type="text/javascript" src="<?php echo e(asset('js/carousel.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/functions.js')); ?>"></script>

        </div>
    </body>
</html>