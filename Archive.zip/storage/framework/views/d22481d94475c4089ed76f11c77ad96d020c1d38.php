<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">

		<div class="xs">
			<h3>Posted listings</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="well1 white">
			    <div class="table-responsive">
    				<table class="table">
    					<thead>
    						<tr>
    							<th>ID</th>
    							<th>Title</th>
    							<th>View</th>
    							<th>Earn</th>
    							<th class="text-center">Action</th>
    						</tr>
    					</thead>
    					<tbody>
    						<?php if($posts->count()): ?>
    							<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    								<tr>
    									<td><?php echo e($post->id); ?></td>
    									<td><?php echo e($post->listing->title); ?></td>
    									<td>
    										<a href="#"><?php echo e($post->views); ?></a>
    									</td>
    									<td>
    										$<?php echo e($post->earn()); ?>

    									</td>
    									<td class="text-center">
    									    <a onclick="event.preventDefault(); document.getElementById('listings-post-form-<?php echo e($post->id); ?>').submit();" href="#" class="btn btn-info btn-sm">Post again</a>
	    									<form class="hidden" action="<?php echo e(route('publisher.promote.store', [$post->listing])); ?>" method="post" id="listings-post-form-<?php echo e($post->id); ?>">
											    <?php echo e(csrf_field()); ?>

											</form>
    									</td>
    								</tr>
    							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						<?php else: ?>
    							<tr>
    								<td class="text-center" colspan="6">
    									<span>No listings found.</span>
    								</td>
    							</tr>
    						<?php endif; ?>
    					</tbody>
    				</table>
				</div><br>
				<div class="text-right">
				    <?php echo e($posts->links()); ?>

				</div>
			</div>
			
		</div>
		
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publisher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>