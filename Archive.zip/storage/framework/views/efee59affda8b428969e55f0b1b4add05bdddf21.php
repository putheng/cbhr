<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Edit company profile</h3>
			<?php echo $__env->make('users.employer.listing.partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<div class="well1 white">
				<form action="<?php echo e(route('employer.profile.company')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

    				<?php echo e(method_field('PATCH')); ?>

					<fieldset>
						
						<avatar-upload endpoint="<?php echo e(route('account.avatar.store')); ?>" send-as="image" current-avatar="<?php echo e(Auth::user()->company->avatarPath()); ?>"></avatar-upload>
						
						<div class="form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
							<label class="control-label">Company :</label>
							<input name="company" type="text" value="<?php echo e($user->company->name); ?>" class="form-control1">
							<?php if($errors->has('company')): ?>
								<span class="help-block"><?php echo e($errors->first('company')); ?></span>
							<?php endif; ?>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('industry') ? ' has-error' : ''); ?>">
									<label class="control-label">Industry :</label>
									<select name="industry" class="form-control1">
										<?php $__currentLoopData = \App\Models\Industry::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(
												isset($user) && $user->company->industry_id == $child->id ||
								                    !isset($user) && !old('industry') ||
								                    old('industry') == $child->id
								            ): ?>
												<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php else: ?>
												<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('industry')): ?>
										<span class="help-block"><?php echo e($errors->first('industry')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
									<label class="control-label">Company Type :</label>
									<select name="type" class="form-control1">
										<?php $__currentLoopData = \App\Models\CompanyType::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(
												isset($user) && $user->company->type_id == $child->id ||
								                    !isset($user) && !old('type') ||
								                    old('type') == $child->id
								            ): ?>
												<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php else: ?>
												<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('type')): ?>
										<span class="help-block"><?php echo e($errors->first('type')); ?></span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('employee') ? ' has-error' : ''); ?>">
									<label class="control-label">Employee :</label>
									<select name="employee" class="form-control1">
										<?php $__currentLoopData = \App\Models\EmployeeType::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if(
												isset($user) && $user->company->employee_id == $child->id ||
								                    !isset($user) && !old('employee') ||
								                    old('employee') == $child->id
								            ): ?>
												<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php else: ?>
												<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('employee')): ?>
										<span class="help-block"><?php echo e($errors->first('employee')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
									<label class="label-control">Phone:</label>
									<input type="text" class="form-control1" name="phone" value="<?php echo e(old('phone') ? old('phone') : $user->company->phone); ?>">
									<?php if($errors->has('phone')): ?>
				                        <div class="help-block">
				                            <?php echo e($errors->first('phone')); ?>

				                        </div>
				                    <?php endif; ?>
								</div>
							</div>
						</div>
						
						<div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
							<label class="label-control">Address:</label>
							<input type="text" class="form-control1" name="address" value="<?php echo e(old('address') ? old('address') : $user->company->address); ?>">
							<?php if($errors->has('address')): ?>
		                        <div class="help-block">
		                            <?php echo e($errors->first('address')); ?>

		                        </div>
		                    <?php endif; ?>
						</div>
						
						<div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
							<label class="label-control">Website:</label>
							<input type="text" class="form-control1" name="website" value="<?php echo e(old('website') ? old('website') : $user->company->website); ?>">
							<?php if($errors->has('website')): ?>
		                        <div class="help-block">
		                            <?php echo e($errors->first('website')); ?>

		                        </div>
		                    <?php endif; ?>
						</div>
						
						<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
							<label class="label-control">Description:</label>
							<textarea class="form-control1" name="description"><?php echo e(old('description') ? old('description') : $user->company->description); ?></textarea>
							<?php if($errors->has('description')): ?>
		                        <div class="help-block">
		                            <?php echo e($errors->first('description')); ?>

		                        </div>
		                    <?php endif; ?>
						</div>
						
						<input type="submit" value="Submit" class="btn btn-info">
					</fieldset>
				</form>
			</div>
			
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>