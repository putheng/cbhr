<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Browse the jobseeker resumes</h3>
			<div class="well1 white">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>POSITION</th>
							<th>QUALIFICATION</th>
							<th>EXPERIENCE</th>
							<th>LEVEL</th>
							<th>FUNCTION</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="text-center" colspan="6">
								<p class="text-center">Don't have any seeker resume.</p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>