<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
    	<strong>Well done!</strong> <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
    	<strong>Error!</strong> <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
