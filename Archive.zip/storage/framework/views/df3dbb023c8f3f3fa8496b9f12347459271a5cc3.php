<div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
	<label class="control-label">Category :</label>
	<select name="category" class="form-control1">
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<optgroup label="<?php echo e($category->name); ?>">
				<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(
						isset($listing) && $listing->category_id == $child->id ||
                            !isset($listing) && !old('category') ||
                            old('category') == $child->id
                    ): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</optgroup>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('category')): ?>
		<span class="help-block"><?php echo e($errors->first('category')); ?></span>
	<?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('term') ? ' has-error' : ''); ?>">
	<label class="control-label">Job Term :</label>
	<select name="term" class="form-control1">
		<?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(
				isset($listing) && $listing->term_id == $child->id ||
                    !isset($listing) && !old('term') ||
                    old('term') == $child->id
            ): ?>
				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php else: ?>
				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('term')): ?>
		<span class="help-block"><?php echo e($errors->first('term')); ?></span>
	<?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
	<label class="control-label">Career Level :</label>
	<select name="level" class="form-control1">
		<?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(
				isset($listing) && $listing->level_id == $child->id ||
                    !isset($listing) && !old('level') ||
                    old('level') == $child->id
            ): ?>
				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php else: ?>
				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('level')): ?>
		<span class="help-block"><?php echo e($errors->first('level')); ?></span>
	<?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('education') ? ' has-error' : ''); ?>">
	<label class="control-label">Education :</label>
	<select name="education" class="form-control1">
		<?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(
				isset($listing) && $listing->education_id == $child->id ||
                    !isset($listing) && !old('education') ||
                    old('education') == $child->id
            ): ?>
				<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php else: ?>
				<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('education')): ?>
		<span class="help-block"><?php echo e($errors->first('education')); ?></span>
	<?php endif; ?>
</div>

<div class="row">
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('salary') ? ' has-error' : ''); ?>">
			<label class="control-label">Salary :</label>
			<select name="salary" class="form-control1">
				<?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(
						isset($listing) && $listing->salary_id == $child->id ||
		                    !isset($listing) && !old('salary') ||
		                    old('salary') == $child->id
		            ): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('salary')): ?>
				<span class="help-block"><?php echo e($errors->first('salary')); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('experience') ? ' has-error' : ''); ?>">
			<label class="control-label">Years of Experience :</label>
			<select name="experience" class="form-control1">
				<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(
						isset($listing) && $listing->experience_id == $child->id ||
		                    !isset($listing) && !old('experience') ||
		                    old('experience') == $child->id
		            ): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('experience')): ?>
				<span class="help-block"><?php echo e($errors->first('experience')); ?></span>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('age') ? ' has-error' : ''); ?>">
			<label class="control-label">Age : (18 - 35...)</label>
			<select name="age" class="form-control1">
				<?php $__currentLoopData = $age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(
						isset($listing) && $listing->age_id == $child->id ||
		                    !isset($listing) && !old('age') ||
		                    old('age') == $child->id
		            ): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('age')): ?>
				<span class="help-block"><?php echo e($errors->first('age')); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
			<label class="control-label">Gender :</label>
			<select name="gender" class="form-control1">
				<?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(
						isset($listing) && $listing->gender_id == $child->id ||
		                    !isset($listing) && !old('gender') ||
		                    old('gender') == $child->id
		            ): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<?php if($errors->has('gender')): ?>
				<span class="help-block"><?php echo e($errors->first('gender')); ?></span>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="form-group<?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
	<label class="control-label">Locations :</label>
	<select name="location" class="form-control1">
		<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<optgroup label="<?php echo e($area->name); ?>">
				<?php $__currentLoopData = $area->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(
						isset($listing) && $listing->area_id == $child->id ||
		                    !isset($listing) && !old('location') ||
		                    old('location') == $child->id
		            ): ?>
						<option selected="selected" value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</optgroup>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<?php if($errors->has('location')): ?>
		<span class="help-block"><?php echo e($errors->first('location')); ?></span>
	<?php endif; ?>
</div>