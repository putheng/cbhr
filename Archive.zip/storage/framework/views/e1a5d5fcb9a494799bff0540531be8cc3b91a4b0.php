<form action="<?php echo e(route('listing.filter')); ?>" method="get">
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Job Type
    		<?php if(request('term')): ?>
    		    <a href="<?php echo e(clear_filter('term')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	
    	<select name="term" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('term') == $term->id ? 'selected' : ''); ?> value="<?php echo e($term->id); ?>"><?php echo e($term->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Level
    		<?php if(request('level')): ?>
    		    <a href="<?php echo e(clear_filter('level')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="level" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('level') == $level->id ? 'selected' : ''); ?> value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Education
    		<?php if(request('education')): ?>
    		    <a href="<?php echo e(clear_filter('education')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="education" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('education') == $edu->id ? 'selected' : ''); ?> value="<?php echo e($edu->id); ?>"><?php echo e($edu->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Salary
    		<?php if(request('salary')): ?>
    		    <a href="<?php echo e(clear_filter('salary')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="salary" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('salary') == $salary->id ? 'selected' : ''); ?> value="<?php echo e($salary->id); ?>"><?php echo e($salary->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Experience
    		<?php if(request('experience')): ?>
    		    <a href="<?php echo e(clear_filter('experience')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="experience" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('experience') == $experience->id ? 'selected' : ''); ?> value="<?php echo e($experience->id); ?>"><?php echo e($experience->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Category
    		<?php if(request('category')): ?>
    		    <a href="<?php echo e(clear_filter('category')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="category" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    
    		    <option class="optionGroup" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
    		    
    		    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		        <option <?php echo e(request('category') == $child->id ? 'selected' : ''); ?> value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
    		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		    
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Location
    		<?php if(request('area')): ?>
    		    <a href="<?php echo e(clear_filter('area')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="area" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    
    		    <option class="optionGroup" <?php echo e(request('area') == $area->id ? 'selected' : ''); ?> value="<?php echo e($area->id); ?>"><?php echo e($area->name); ?></option>
    		    
    		    <?php $__currentLoopData = $area->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		        <option <?php echo e(request('area') == $child->id ? 'selected' : ''); ?> value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?></option>
    		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		    
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Gender
    		<?php if(request('gender')): ?>
    		    <a href="<?php echo e(clear_filter('gender')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="gender" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('gender') == $sex->id ? 'selected' : ''); ?> value="<?php echo e($sex->id); ?>"><?php echo e($sex->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <div class="gray-wrap">
    	<h4 class="aside-header">
    		Age
    		<?php if(request('age')): ?>
    		    <a href="<?php echo e(clear_filter('age')); ?>" class="h6 pull-right text-primary">Clear</a>
    		<?php endif; ?>
    	</h4>
    	<hr class="top-bottom-margin">
    	<select name="age" class="form-control">
    		<option value="">All</option>
    		<?php $__currentLoopData = $age; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $old): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		    <option <?php echo e(request('age') == $old->id ? 'selected' : ''); ?> value="<?php echo e($old->id); ?>"><?php echo e($old->name); ?></option>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</select>
    	<div class="clearfix"></div>
    	<br>
    </div>
    
    <br>
    <input type="submit" value="Search" class="btn btn-primary">
</form>