<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Create Listing</h3>
			<div class="well1 white">
				<form class="form-floating" novalidate="novalidate" action="<?php echo e(route('employer.listing.create')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<fieldset>
						<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
							<label class="control-label">Title :</label>
							<input name="title" type="text" value="<?php echo e(old('title')); ?>" class="form-control1">
							<?php if($errors->has('title')): ?>
								<span class="help-block"><?php echo e($errors->first('title')); ?></span>
							<?php endif; ?>
						</div>
						
						<?php echo $__env->make('users.employer.listing.partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
						<div class="form-group<?php echo e($errors->has('requirement') ? ' has-error' : ''); ?>">
							<label class="control-label">Requirements :</label>
							<textarea name="requirement" class="form-control1" style="height:100px;"><?php echo e(old('requirement')); ?></textarea>
							<?php if($errors->has('requirement')): ?>
								<span class="help-block"><?php echo e($errors->first('requirement')); ?></span>
							<?php endif; ?>
						</div>
						
						<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
							<label class="control-label">Description :</label>
							<textarea name="description" class="form-control1" style="height:100px;"><?php echo e(old('description')); ?></textarea>
							<?php if($errors->has('description')): ?>
								<span class="help-block"><?php echo e($errors->first('description')); ?></span>
							<?php endif; ?>
						</div>
						
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('start') ? ' has-error' : ''); ?>">
									<label class="control-label">Start Date :</label>
									<input name="start" type="date" value="<?php echo e(old('start')); ?>" class="form-control1">
									<?php if($errors->has('start')): ?>
										<span class="help-block"><?php echo e($errors->first('start')); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group<?php echo e($errors->has('closing') ? ' has-error' : ''); ?>">
									<label class="control-label">Closing Date :</label>
									<input name="closing" type="date" value="<?php echo e(old('closing')); ?>" class="form-control1">
									<?php if($errors->has('closing')): ?>
										<span class="help-block"><?php echo e($errors->first('closing')); ?></span>
									<?php endif; ?>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<button type="submit" class="btn btn-primary">Submit</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
					</fieldset>
				</form>
			</div>
					
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>