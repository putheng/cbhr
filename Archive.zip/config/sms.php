<?php

return [

    'nexmo_key'     => env('NEXMO_KEY'),

    'nexmo_secret'  => env('NEXMO_SECRET'),

    'nexmo_admin'  => env('NEXMO_ADMIN_NUMBER'),

];
