<div class="gray-wrap">
	<h4 class="aside-header">Related Jobs</h4>
	<hr class="top-bottom-margin">
	<div>			
		<h5 class="no-margin">
			<a class="jobDetail" href="">{{ $listing->title }}</a>
		</h5>
		<span class="sub-text"> ស្វាគមន៍ភ្ញៀវ កក់តុសំរាប់ភ្ញៀវ រៀបចំនិងលើកម្ហូបសំរា ...</span>
	</div>
	<div class="clearfix"></div>
	<hr class="top-bottom-margin">
	<div class="text-center">
		<a class="underline-link" href="#">See All</a>
	</div>
	<br>
</div>
<br>
<h3 class="aside-header">Advertisements</h3>
<hr class="top-bottom-margin">
<div class="hide text-center"></div>