<div class="footer-bottom">
	<div class="container">
		<div class="white-font pull-left">
			Copyright @ {{ date('Y') }} CambodiaHR. ALL right reserved. <a style="color: #F88;font-weight: bold;text-decoration: underline;" href="mailto:contact@cambodiahr.com">contact@cambodiahr.com</a>
			<!---->
		</div>
		<div class="footer-credits text-center white-font pull-right">CambodiaHR is Cambodia’s leading human resources and recruitment site.
		</div>
		<div class="clearfix"></div>
	</div>
</div>