<div class="header">
   <div class="container">
      <div class="header_top">
	      <div class="header-left">
					 <div class="logo wow bounceInDown" data-wow-delay="0.4s">
						<a href="index.html"><img src="images/logo-4.png" alt=""/></a>
					 </div>
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">
						    	<li class="active"><a href="index.html">Product</a></li>
						    	<li><a href="website.html">Website</a></li>
						    	<li><a href="pricing.html">Pricing</a></li>
						    	<li><a href="features.html">Features</a></li>
						    	<div class="clearfix"></div>
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
				    </div>
				    <div class="clearfix"></div>
	      </div>
	      <ul class="phone wow fadeInUpBig" data-wow-delay="0.4s">
	      	<li><i class="ph_icon"> </i></li>
	      	<li><p>+855 77 977 794</p></li>
	      </ul>
	      <div class="clearfix"> </div>
	   </div>
	   <div class="header_bottom">
	   	  <h1 class="m_head wow rollIn" data-wow-delay="0.4s">Virtual Private Servers (VPS)<br> <span class="h4">Performance, security and availability for all your needs.</span></h1>
	   	  <div class="video_buttons">
		   	  <div class="video_but"> <a href="#" class="fa-btn btn-1 btn-1e">Sign Up Now</a></div>
		   	  <div class="video_right">
		   	            <a class="play-icon popup-with-zoom-anim" href="#small-dialog">
							<span> </span><p class="video_desc">Watch the video</p>
						</a>
						<div id="small-dialog" class="mfp-hide">
						<iframe width="560" height="315" src="//www.youtube.com/embed/n7rzi2hGAzA" frameborder="0" allowfullscreen></iframe>
					  </div>
			  </div>
		      <div class="clearfix"></div>
		 </div>
	   </div>
	   <div class="clearfix"></div>
	</div>
</div>