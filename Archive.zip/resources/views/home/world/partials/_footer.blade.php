<div class="footer_icon">
	<i class="icon"><img src="images/footer_icon.png"> </i>
</div>
<div class="footer">
	<div class="container">
	 <div class="col-md-2 span_2">
	   	 <h3>Proteectly</h3>
	   	 <ul class="list1">
	   	 	<li><a href="contact.html">contact</a></li>
	   	 	<li><a href="#">Enterprise Features</a></li>
	   	 	<li><a href="#">Why Us?</a></li>
	   	 	<li><a href="#">Solution</a></li>
	   	 	<li><a href="#">Pricing</a></li>
	   	 </ul>
	   </div>
	   <div class="col-md-2 span_2">
	   	 <h3>About Us</h3>
	   	 <ul class="list1">
	   	 	<li><a href="#">Our Story</a></li>
	   	 	<li><a href="#">Our Leadership</a></li>
	   	 	<li><a href="#">Our Investors</a></li>
	   	 	<li><a href="#">Jobs</a></li>
	   	 </ul>
	   </div>
	   <div class="col-md-2 span_2">
	   	 <h3>Support</h3>
	   	 <ul class="list1">
	   	 	<li><a href="#">Help</a></li>
	   	 	<li><a href="#">Privacy Policy</a></li>
	   	 	<li><a href="#">Terms of Use</a></li>
	   	 	<li><a href="#">Solution</a></li>
	   	 	<li><a href="#">Pricing</a></li>
	   	 </ul>
	   </div>
	   <div class="col-md-6 span_3 wow fadeInRight" data-wow-delay="0.4s">
	   	   <ul class="list2 list3">
	   	   	 <i class="phone"> </i>
	   	   	 <li class="phone_desc"><p>+855 77 977 794</p></li>
	   	   	 <div class="clearfix"> </div>
	   	   </ul>
	   	   <ul class="list2">
	   	   	 <i class="msg"> </i>
	   	   	 <li class="phone_desc"><p><a href="mailto:info@cambodiahr.com">info@cambodiahr.com</a></p></li>
	   	   	 <div class="clearfix"> </div>
	   	   </ul>
	   </div>
	</div>
</div>
</body>
</html>