<title>Cambodia HR | World</title>
<meta name="viewport" content="width=1024">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Khmer Web Hosting, Khmer Web design, Buy domain, domain registration, Cambodia Hosting, Web Application Company, Cheapest hosting in Cambodia, Good Services hosting in Cambodia" />
<meta name="description" content="Cambodia HR Host Provides Web Hosting Service with the best quality and low cost in Cambodia." />
<link href="images/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="{{ asset('css/bootstrap-b.css') }}" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="{{ asset('css/hosting.css') }}" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<!--webfont-->
<script type="text/javascript" src="{{ asset('js/jquery-1.11.1.min.js') }}"></script>
<!--webfont-->
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- Add fancyBox main JS and CSS files -->
<script src="{{ asset('js/jquery.magnific-popup.js') }}" type="text/javascript"></script>
<link href="{{ asset('css/popup.css') }}" rel="stylesheet" type="text/css">
	<script>
		$(document).ready(function() {
				$('.popup-with-zoom-anim').magnificPopup({
					type: 'inline',
					fixedContentPos: false,
					fixedBgPos: true,
					overflowY: 'auto',
					closeBtnInside: true,
					preloader: false,
					midClick: true,
					removalDelay: 300,
					mainClass: 'my-mfp-zoom-in'
			});
		});
	</script>
<!--Animation-->
<script src="{{ asset('js/wow.min.js') }}"></script>
<link href="{{ asset('css/animate.css') }}" rel='stylesheet' type='text/css' />
<script>
	new WOW().init();
</script>