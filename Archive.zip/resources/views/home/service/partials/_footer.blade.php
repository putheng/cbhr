		<div id="copyright-wrapper" class="normal-copyright  clearfix">
			<div class="container">
				<div id="copyright-text">
					<p>© {{ date('Y') }} — Cambodia HR - Digital Agency -
						Website / Mobile App Development in Phnom Penh, Cambodia.
					</p>
				</div>
				<div id="footer-menu" class="clearfix">
					<ul id="footer-nav">
						<li id="menu-item-6644" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6644">
							<a href="#disclaimer/">VPS</a>
						</li>
						<li id="menu-item-6643" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6643">
							<a href="#terms-of-use/">Hosting</a>
						</li>
						<li id="menu-item-6645" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6645">
							<a href="#privacypolicy/">Domains</a>
						</li>
						<li id="menu-item-6646" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6646">
							<a href="#sitemap/">SSL Certificates</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="{{ asset('js/service/bb3a09.js') }}"></script>
<script src="{{ asset('js/service/1d3985.js') }}"></script>
<script src="{{ asset('js/service/ac6fb4.js') }}"></script>