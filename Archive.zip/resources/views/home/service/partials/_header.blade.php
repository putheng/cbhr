<div id="mobile-menu-wrap">
<div class="hb-top-holder"></div>
<a class="mobile-menu-close"><i class="hb-icon-x"></i></a>
<nav id="mobile-menu" class="clearfix interactive">
	<div class="menu-custom1-container">
		<ul id="menu-custom1" class="menu-main-menu-container">
			<li id="menu-item-5551" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-5551">
				<a href="#">Home</a>
			</li>
			<li id="menu-item-5541" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-5541">
				<a href="#services/"><span>Services</span></a>
				<ul  class="sub-menu" style=''>
					<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5924"><a href="#website-design-company/"><span>Web Dev</span></a></li>
					<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-5855 current_page_item menu-item-5877"><a href="#"><span>Mobile App Dev</span></a></li>
					<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6032"><a href="#parse-data-migration/"><span>Parse Data Migration</span></a></li>
					<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6029">
					    <a href="#">
					        <span>VPS</span>
					     </a>
					 </li>
					 <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6029">
					    <a href="#">
					        <span>Hosting</span>
					     </a>
					 </li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6029">
					    <a href="#">
					        <span>Domains</span>
					     </a>
					 </li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6029">
					    <a href="#">
					        <span>SSL Certificates</span>
					     </a>
					 </li>
				</ul>
			</li>
			<li id="menu-item-5539" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5539">
				<a href="#portfolio/">Portfolio</a>
			</li>
			<li id="menu-item-5543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5543">
				<a href="#jobs/">Jobs</a>
			</li>
			<li id="menu-item-6416" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6416">
				<a href="#blog/">Blog</a>
			</li>
			<li id="menu-item-5557" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5557">
				<a href="#contactus/">Contact</a>
			</li>
		</ul>
	</div>
</nav>
</div>