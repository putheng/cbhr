    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
	<!-- Metis Menu Plugin JavaScript -->
	<script src="{{ asset('js/emp/metisMenu.min.js') }}"></script>
	<!-- Graph JavaScript -->
	<script src="{{ asset('js/emp/custom.js') }}"></script>