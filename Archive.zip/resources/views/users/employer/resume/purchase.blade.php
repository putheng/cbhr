@extends('layouts.employer')

@section('content')
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>Jobseeker Resumes</h3>
			<div class="well1 white">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>POSITION</th>
							<th>QUALIFICATION</th>
							<th>EXPERIENCE</th>
							<th>LEVEL</th>
							<th>FUNCTION</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="text-center" colspan="6">
								<p class="text-center">Empty</p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
@endsection