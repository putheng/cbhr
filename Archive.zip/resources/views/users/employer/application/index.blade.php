@extends('layouts.employer')

@section('content')
<div id="page-wrapper">
	<div class="col-md-12 graphs">
		<div class="xs">
			<h3>List of the jobseekers applied for your jobs</h3>
			
			<div class="well1 white">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>DATE</th>
							<th>NAME</th>
							<th>POSITION</th>
							<th class="text-center">ACTION</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="text-center" colspan="5">
								<span>Empty</span>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
			
		</div>
		<!-- /Footer -->
		
		<!-- /End footer -->
	</div>
</div>
<!-- /#page-wrapper -->
@endsection