@extends('home.index')

@section('content')

@endsection