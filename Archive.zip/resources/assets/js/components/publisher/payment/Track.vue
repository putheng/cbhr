<template>
	<div>Hello text</div>
</template>
<script>
    export default{
        props:[

        ],
        data(){
	    	return {
	    		
	    	}
        },
        methods:{
        	
        }
    }
</script>